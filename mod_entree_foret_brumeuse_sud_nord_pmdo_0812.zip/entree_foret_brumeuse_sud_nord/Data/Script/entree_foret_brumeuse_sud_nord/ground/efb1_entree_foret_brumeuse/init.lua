-- efb1_entree_foret_brumeuse : base d edition, aucun warp.
local efb1_entree_foret_brumeuse = {}
return efb1_entree_foret_brumeuse
