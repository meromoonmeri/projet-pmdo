-- zfb1_zone_foret_brumeuse : base d edition, aucun warp.
local zfb1_zone_foret_brumeuse = {}
return zfb1_zone_foret_brumeuse
