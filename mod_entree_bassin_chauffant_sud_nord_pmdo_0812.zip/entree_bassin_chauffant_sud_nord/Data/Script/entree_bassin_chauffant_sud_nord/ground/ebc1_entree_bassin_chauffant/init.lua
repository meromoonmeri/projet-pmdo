-- ebc1_entree_bassin_chauffant : base d edition, aucun warp.
local ebc1_entree_bassin_chauffant = {}
return ebc1_entree_bassin_chauffant
