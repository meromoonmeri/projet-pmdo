-- bmf1_bosquet_mycelien : base d edition, aucun warp.
local bmf1_bosquet_mycelien = {}
return bmf1_bosquet_mycelien
