-- raf3_fond_fleuri : base d edition (fin de donjon), aucun warp.
local raf3_fond_fleuri = {}
return raf3_fond_fleuri
