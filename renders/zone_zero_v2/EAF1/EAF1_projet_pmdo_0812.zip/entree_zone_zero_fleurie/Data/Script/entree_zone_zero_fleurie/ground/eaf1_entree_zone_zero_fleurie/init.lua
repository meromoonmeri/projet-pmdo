-- eaf1_entree_zone_zero_fleurie : base d edition (fin de donjon), aucun warp.
local eaf1_entree_zone_zero_fleurie = {}
return eaf1_entree_zone_zero_fleurie
