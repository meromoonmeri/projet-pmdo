-- raf1_levre_cratere_fleurie : base d edition (fin de donjon), aucun warp.
local raf1_levre_cratere_fleurie = {}
return raf1_levre_cratere_fleurie
