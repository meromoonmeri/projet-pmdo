-- raf2_terrasses_fleuries : base d edition (fin de donjon), aucun warp.
local raf2_terrasses_fleuries = {}
return raf2_terrasses_fleuries
