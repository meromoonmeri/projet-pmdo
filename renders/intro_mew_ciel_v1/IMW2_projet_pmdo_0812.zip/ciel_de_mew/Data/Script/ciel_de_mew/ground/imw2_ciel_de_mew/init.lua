-- imw2_ciel_de_mew : base d edition (fin de donjon), aucun warp.
local imw2_ciel_de_mew = {}
return imw2_ciel_de_mew
