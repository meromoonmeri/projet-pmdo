-- zrv2_zone_reveil_jour : zone de reveil V2 (jour), base d edition, aucun warp.
-- Marqueurs : reveil (au bord de la prairie, face a l ocean), entrance (sud).
local zrv2_zone_reveil_jour = {}
return zrv2_zone_reveil_jour
