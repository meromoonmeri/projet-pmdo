-- zrv2_zone_reveil_crepuscule : zone de reveil V2 (crepuscule), base d edition, aucun warp.
-- Marqueurs : reveil (au bord de la prairie, face a l ocean), entrance (sud).
local zrv2_zone_reveil_crepuscule = {}
return zrv2_zone_reveil_crepuscule
