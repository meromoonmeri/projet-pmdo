-- zrv2_zone_reveil_aube : zone de reveil V2 (aube), base d edition, aucun warp.
-- Marqueurs : reveil (au bord de la prairie, face a l ocean), entrance (sud).
local zrv2_zone_reveil_aube = {}
return zrv2_zone_reveil_aube
