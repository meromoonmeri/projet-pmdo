-- zrv2_zone_reveil_nuit : zone de reveil V2 (nuit), base d edition, aucun warp.
-- Marqueurs : reveil (au bord de la prairie, face a l ocean), entrance (sud).
local zrv2_zone_reveil_nuit = {}
return zrv2_zone_reveil_nuit
