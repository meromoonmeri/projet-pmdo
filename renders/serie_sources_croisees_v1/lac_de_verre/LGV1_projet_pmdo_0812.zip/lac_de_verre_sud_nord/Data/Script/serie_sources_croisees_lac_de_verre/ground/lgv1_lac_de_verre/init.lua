-- lgv1_lac_de_verre : base d’édition; aucun warp.
local lgv1_lac_de_verre = {}
return lgv1_lac_de_verre
