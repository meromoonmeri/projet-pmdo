-- lgv1_lac_de_verre : variante de D52P11A; aucun warp.
local lgv1_lac_de_verre = {}
return lgv1_lac_de_verre
