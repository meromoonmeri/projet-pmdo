-- emb1_entree_mt_blaze_sud_nord : base d edition, aucun warp.
local emb1_entree_mt_blaze_sud_nord = {}
return emb1_entree_mt_blaze_sud_nord
