-- emb1_entree_mt_blaze_sud_nord : fin, aucun warp.
local emb1_entree_mt_blaze_sud_nord = {}
return emb1_entree_mt_blaze_sud_nord
