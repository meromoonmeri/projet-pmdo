-- emb1_entree_mt_blaze : base d edition, aucun warp.
local emb1_entree_mt_blaze = {}
return emb1_entree_mt_blaze
