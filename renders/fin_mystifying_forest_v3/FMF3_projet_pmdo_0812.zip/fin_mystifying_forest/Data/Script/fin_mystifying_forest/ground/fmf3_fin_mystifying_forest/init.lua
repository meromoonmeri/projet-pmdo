-- fmf3_fin_mystifying_forest : base d edition, aucun warp.
local fmf3_fin_mystifying_forest = {}
return fmf3_fin_mystifying_forest
