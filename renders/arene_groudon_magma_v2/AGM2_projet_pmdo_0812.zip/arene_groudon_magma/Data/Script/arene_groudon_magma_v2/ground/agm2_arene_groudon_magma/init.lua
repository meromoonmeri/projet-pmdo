-- agm2_arene_groudon_magma : base d edition, aucun warp.
local agm2_arene_groudon_magma = {}
return agm2_arene_groudon_magma
