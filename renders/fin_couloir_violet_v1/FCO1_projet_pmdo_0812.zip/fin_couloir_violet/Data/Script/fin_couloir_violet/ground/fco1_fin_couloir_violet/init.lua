-- fco1_fin_couloir_violet : base d edition, aucun warp.
local fco1_fin_couloir_violet = {}
return fco1_fin_couloir_violet
