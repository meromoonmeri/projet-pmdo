-- fvc1_fin_couloir_violet; aucun warp.
local fvc1_fin_couloir_violet = {}
return fvc1_fin_couloir_violet
