-- ecv1_entree_couloir_violet : base d edition, aucun warp.
local ecv1_entree_couloir_violet = {}
return ecv1_entree_couloir_violet
