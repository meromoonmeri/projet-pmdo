-- clr2_colonnes_lances_sommet : base d edition (fin de donjon), aucun warp.
local clr2_colonnes_lances_sommet = {}
return clr2_colonnes_lances_sommet
