-- fmt3_fin_mt_thunder : base d edition, aucun warp.
local fmt3_fin_mt_thunder = {}
return fmt3_fin_mt_thunder
