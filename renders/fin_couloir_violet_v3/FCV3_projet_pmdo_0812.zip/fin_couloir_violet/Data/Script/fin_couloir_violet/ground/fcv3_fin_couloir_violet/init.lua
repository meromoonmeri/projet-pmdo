-- fcv3_fin_couloir_violet : base d edition, aucun warp.
local fcv3_fin_couloir_violet = {}
return fcv3_fin_couloir_violet
