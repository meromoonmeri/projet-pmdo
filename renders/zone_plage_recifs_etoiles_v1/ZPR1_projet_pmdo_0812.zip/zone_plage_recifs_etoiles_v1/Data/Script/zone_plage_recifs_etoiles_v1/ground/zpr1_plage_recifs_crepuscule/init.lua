-- zpr1_plage_recifs_crepuscule : plage aux recifs etoiles ZPR1 (crepuscule), base d edition, aucun warp.
-- Marqueurs : plage (bord de l eau), entrance (sortie sud).
local zpr1_plage_recifs_crepuscule = {}
return zpr1_plage_recifs_crepuscule
