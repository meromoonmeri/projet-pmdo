-- zpr1_plage_recifs_nuit : plage aux recifs etoiles ZPR1 (nuit), base d edition, aucun warp.
-- Marqueurs : plage (bord de l eau), entrance (sortie sud).
local zpr1_plage_recifs_nuit = {}
return zpr1_plage_recifs_nuit
