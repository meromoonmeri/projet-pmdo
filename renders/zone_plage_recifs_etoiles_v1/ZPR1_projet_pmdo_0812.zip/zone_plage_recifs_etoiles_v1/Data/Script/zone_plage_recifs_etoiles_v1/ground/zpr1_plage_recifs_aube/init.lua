-- zpr1_plage_recifs_aube : plage aux recifs etoiles ZPR1 (aube), base d edition, aucun warp.
-- Marqueurs : plage (bord de l eau), entrance (sortie sud).
local zpr1_plage_recifs_aube = {}
return zpr1_plage_recifs_aube
