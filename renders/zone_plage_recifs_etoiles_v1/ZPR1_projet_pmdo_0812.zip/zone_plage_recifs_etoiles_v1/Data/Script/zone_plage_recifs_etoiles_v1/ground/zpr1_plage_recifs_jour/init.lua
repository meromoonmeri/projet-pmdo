-- zpr1_plage_recifs_jour : plage aux recifs etoiles ZPR1 (jour), base d edition, aucun warp.
-- Marqueurs : plage (bord de l eau), entrance (sortie sud).
local zpr1_plage_recifs_jour = {}
return zpr1_plage_recifs_jour
