-- etc1_entree_clairiere_tropicale : base d edition, aucun warp.
local etc1_entree_clairiere_tropicale = {}
return etc1_entree_clairiere_tropicale
