-- ecl1_entree_colonnes_lances : base d edition (fin de donjon), aucun warp.
local ecl1_entree_colonnes_lances = {}
return ecl1_entree_colonnes_lances
