-- ftn1_fin_mt_thunder : base d edition, aucun warp.
local ftn1_fin_mt_thunder = {}
return ftn1_fin_mt_thunder
