-- emt1_entree_mt_thunder : base d edition, aucun warp.
local emt1_entree_mt_thunder = {}
return emt1_entree_mt_thunder
