-- emb2_entree_mt_blaze_sud_nord_v2 : base d edition, aucun warp.
local emb2_entree_mt_blaze_sud_nord_v2 = {}
return emb2_entree_mt_blaze_sud_nord_v2
