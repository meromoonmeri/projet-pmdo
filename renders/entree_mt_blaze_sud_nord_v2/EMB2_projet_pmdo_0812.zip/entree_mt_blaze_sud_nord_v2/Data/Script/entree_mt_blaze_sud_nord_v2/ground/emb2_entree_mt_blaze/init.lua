-- emb2_entree_mt_blaze : base d edition, aucun warp.
local emb2_entree_mt_blaze = {}
return emb2_entree_mt_blaze
