-- fth1_fin_mt_thunder : base d edition, aucun warp.
local fth1_fin_mt_thunder = {}
return fth1_fin_mt_thunder
