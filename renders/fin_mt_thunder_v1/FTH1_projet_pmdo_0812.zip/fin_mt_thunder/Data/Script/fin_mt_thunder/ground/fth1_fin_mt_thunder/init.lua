-- fth1_fin_mt_thunder; aucun warp.
local fth1_fin_mt_thunder = {}
return fth1_fin_mt_thunder
