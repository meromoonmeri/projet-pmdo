-- ejs2_entree_jardin_secret_temple : base d edition, aucun warp.
local ejs2_entree_jardin_secret_temple = {}
return ejs2_entree_jardin_secret_temple
