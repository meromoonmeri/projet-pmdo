-- fjs1_fin_jungle_sud : base d edition (fin de donjon), aucun warp.
local fjs1_fin_jungle_sud = {}
return fjs1_fin_jungle_sud
