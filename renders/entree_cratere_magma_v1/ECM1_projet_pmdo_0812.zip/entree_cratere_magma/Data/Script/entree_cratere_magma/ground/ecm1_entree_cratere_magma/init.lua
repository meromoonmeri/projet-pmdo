-- ecm1_entree_cratere_magma : base d edition, aucun warp.
local ecm1_entree_cratere_magma = {}
return ecm1_entree_cratere_magma
