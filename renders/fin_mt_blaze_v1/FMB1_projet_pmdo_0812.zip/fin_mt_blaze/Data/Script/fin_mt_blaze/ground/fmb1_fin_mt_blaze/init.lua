-- fmb1_fin_mt_blaze : base d edition, aucun warp.
local fmb1_fin_mt_blaze = {}
return fmb1_fin_mt_blaze
