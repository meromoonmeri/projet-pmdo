-- fmb1_fin_mt_blaze : fin, aucun warp.
local fmb1_fin_mt_blaze = {}
return fmb1_fin_mt_blaze
