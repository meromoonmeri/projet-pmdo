-- fjs4_fin_jardin_secret : base d edition, aucun warp.
local fjs4_fin_jardin_secret = {}
return fjs4_fin_jardin_secret
