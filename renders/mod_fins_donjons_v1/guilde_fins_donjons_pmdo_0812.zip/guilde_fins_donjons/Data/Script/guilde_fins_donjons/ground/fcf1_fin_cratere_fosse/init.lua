-- fcf1_fin_cratere_fosse : base d edition (fin de donjon), aucun warp.
local fcf1_fin_cratere_fosse = {}
return fcf1_fin_cratere_fosse
