-- fwc1_fin_waterfall_cave : base d edition (fin de donjon), aucun warp.
local fwc1_fin_waterfall_cave = {}
return fwc1_fin_waterfall_cave
