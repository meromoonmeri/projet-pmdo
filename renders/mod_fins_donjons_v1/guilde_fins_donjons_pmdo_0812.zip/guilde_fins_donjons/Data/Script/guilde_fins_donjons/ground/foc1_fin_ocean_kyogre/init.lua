-- foc1_fin_ocean_kyogre : base d edition (fin de donjon), aucun warp.
local foc1_fin_ocean_kyogre = {}
return foc1_fin_ocean_kyogre
