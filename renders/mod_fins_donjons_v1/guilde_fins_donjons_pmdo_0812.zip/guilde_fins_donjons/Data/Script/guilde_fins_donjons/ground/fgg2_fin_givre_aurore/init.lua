-- fgg2_fin_givre_aurore : base d edition (fin de donjon), aucun warp.
local fgg2_fin_givre_aurore = {}
return fgg2_fin_givre_aurore
