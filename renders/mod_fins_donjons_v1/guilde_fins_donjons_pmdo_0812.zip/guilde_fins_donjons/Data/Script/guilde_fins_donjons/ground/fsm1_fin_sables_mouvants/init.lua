-- fsm1_fin_sables_mouvants : base d edition, aucun warp.
local fsm1_fin_sables_mouvants = {}
return fsm1_fin_sables_mouvants
