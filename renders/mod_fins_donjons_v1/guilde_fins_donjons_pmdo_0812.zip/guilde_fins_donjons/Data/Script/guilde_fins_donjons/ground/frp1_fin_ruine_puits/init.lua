-- frp1_fin_ruine_puits : base d edition (fin de donjon), aucun warp.
local frp1_fin_ruine_puits = {}
return frp1_fin_ruine_puits
