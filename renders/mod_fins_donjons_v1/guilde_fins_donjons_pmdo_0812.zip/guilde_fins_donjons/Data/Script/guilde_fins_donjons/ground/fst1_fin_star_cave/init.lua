-- fst1_fin_star_cave : base d edition, aucun warp.
local fst1_fin_star_cave = {}
return fst1_fin_star_cave
