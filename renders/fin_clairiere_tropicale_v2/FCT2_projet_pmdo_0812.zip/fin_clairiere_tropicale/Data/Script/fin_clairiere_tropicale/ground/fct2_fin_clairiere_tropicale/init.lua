-- fct2_fin_clairiere_tropicale : base d edition, aucun warp.
local fct2_fin_clairiere_tropicale = {}
return fct2_fin_clairiere_tropicale
