-- zrv1_zone_reveil_jour : zone de reveil (jour), base d edition, aucun warp.
-- Marqueurs : reveil (au bord de la prairie, face a l ocean), entrance (sud).
local zrv1_zone_reveil_jour = {}
return zrv1_zone_reveil_jour
