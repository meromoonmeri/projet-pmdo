-- zrv1_zone_reveil_aube : zone de reveil (aube), base d edition, aucun warp.
-- Marqueurs : reveil (au bord de la prairie, face a l ocean), entrance (sud).
local zrv1_zone_reveil_aube = {}
return zrv1_zone_reveil_aube
