-- zrv1_zone_reveil_nuit : zone de reveil (nuit), base d edition, aucun warp.
-- Marqueurs : reveil (au bord de la prairie, face a l ocean), entrance (sud).
local zrv1_zone_reveil_nuit = {}
return zrv1_zone_reveil_nuit
