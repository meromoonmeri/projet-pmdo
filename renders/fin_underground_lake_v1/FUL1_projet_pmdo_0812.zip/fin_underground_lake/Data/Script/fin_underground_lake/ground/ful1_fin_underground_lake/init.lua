-- ful1_fin_underground_lake : fin, aucun warp.
local ful1_fin_underground_lake = {}
return ful1_fin_underground_lake
