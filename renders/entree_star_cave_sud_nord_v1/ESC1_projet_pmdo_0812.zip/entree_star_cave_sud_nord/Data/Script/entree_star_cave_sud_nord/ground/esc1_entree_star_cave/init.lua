-- esc1_entree_star_cave : base d edition, aucun warp.
local esc1_entree_star_cave = {}
return esc1_entree_star_cave
