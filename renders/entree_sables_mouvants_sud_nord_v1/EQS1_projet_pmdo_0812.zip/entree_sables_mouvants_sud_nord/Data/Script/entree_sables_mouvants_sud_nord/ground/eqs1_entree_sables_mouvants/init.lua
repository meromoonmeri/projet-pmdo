-- eqs1_entree_sables_mouvants : base d edition, aucun warp.
local eqs1_entree_sables_mouvants = {}
return eqs1_entree_sables_mouvants
