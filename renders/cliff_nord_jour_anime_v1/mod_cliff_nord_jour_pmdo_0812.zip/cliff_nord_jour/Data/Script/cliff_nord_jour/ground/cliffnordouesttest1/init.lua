-- cliffnordouesttest1 : nuages et mer animes.
local cliffnordouesttest1 = {}
return cliffnordouesttest1
