-- cliffdaytest : nuages et mer animes.
local cliffdaytest = {}
return cliffdaytest
