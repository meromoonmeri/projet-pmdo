-- ffb1_fin_foret_brumeuse : base d edition, aucun warp.
local ffb1_fin_foret_brumeuse = {}
return ffb1_fin_foret_brumeuse
