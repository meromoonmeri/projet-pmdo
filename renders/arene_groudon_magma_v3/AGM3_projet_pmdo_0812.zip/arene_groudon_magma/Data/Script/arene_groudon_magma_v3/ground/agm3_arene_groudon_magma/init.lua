-- agm3_arene_groudon_magma : base d edition, aucun warp.
local agm3_arene_groudon_magma = {}
return agm3_arene_groudon_magma
