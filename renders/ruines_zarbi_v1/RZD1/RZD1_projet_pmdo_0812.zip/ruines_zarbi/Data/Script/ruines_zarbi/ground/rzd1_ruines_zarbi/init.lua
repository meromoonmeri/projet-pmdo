-- rzd1_ruines_zarbi : base d edition (fin de donjon), aucun warp.
local rzd1_ruines_zarbi = {}
return rzd1_ruines_zarbi
