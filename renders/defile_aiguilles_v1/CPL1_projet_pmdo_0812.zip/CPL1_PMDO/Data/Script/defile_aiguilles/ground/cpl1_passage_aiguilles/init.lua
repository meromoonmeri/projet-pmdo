-- cpl1_passage_aiguilles: projet d'édition, pas de warp automatique.
return {}
