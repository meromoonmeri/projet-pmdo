-- ejs1_entree_jardin_secret : base d edition, aucun warp.
local ejs1_entree_jardin_secret = {}
return ejs1_entree_jardin_secret
