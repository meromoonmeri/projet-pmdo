-- fbs1_fin_bristle_sommet : base d edition (fin de donjon), aucun warp.
local fbs1_fin_bristle_sommet = {}
return fbs1_fin_bristle_sommet
