-- fmb2_fin_mt_blaze_v2 : base d edition, aucun warp.
local fmb2_fin_mt_blaze_v2 = {}
return fmb2_fin_mt_blaze_v2
