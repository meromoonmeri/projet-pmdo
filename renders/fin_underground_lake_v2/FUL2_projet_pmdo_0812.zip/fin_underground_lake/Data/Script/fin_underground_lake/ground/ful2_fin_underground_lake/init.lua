-- ful2_fin_underground_lake : base d edition, aucun warp.
local ful2_fin_underground_lake = {}
return ful2_fin_underground_lake
