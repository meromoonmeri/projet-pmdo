-- fco2_fin_couloir_violet : base d edition, aucun warp.
local fco2_fin_couloir_violet = {}
return fco2_fin_couloir_violet
