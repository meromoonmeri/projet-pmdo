-- atp1_arene_terapagos : base d edition (fin de donjon), aucun warp.
local atp1_arene_terapagos = {}
return atp1_arene_terapagos
