-- eaz1_entree_zone_zero : base d edition (fin de donjon), aucun warp.
local eaz1_entree_zone_zero = {}
return eaz1_entree_zone_zero
