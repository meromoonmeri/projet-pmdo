-- raz2_terrasses_cascades : base d edition (fin de donjon), aucun warp.
local raz2_terrasses_cascades = {}
return raz2_terrasses_cascades
