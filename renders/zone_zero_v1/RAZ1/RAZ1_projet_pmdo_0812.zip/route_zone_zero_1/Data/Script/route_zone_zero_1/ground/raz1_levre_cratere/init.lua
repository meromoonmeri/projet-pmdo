-- raz1_levre_cratere : base d edition (fin de donjon), aucun warp.
local raz1_levre_cratere = {}
return raz1_levre_cratere
