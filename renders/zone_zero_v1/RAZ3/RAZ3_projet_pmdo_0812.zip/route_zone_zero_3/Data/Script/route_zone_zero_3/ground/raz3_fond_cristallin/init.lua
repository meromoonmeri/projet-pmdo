-- raz3_fond_cristallin : base d edition (fin de donjon), aucun warp.
local raz3_fond_cristallin = {}
return raz3_fond_cristallin
