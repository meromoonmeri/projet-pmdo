-- fvs1_fin_vapeur_sommet : base d edition (fin de donjon), aucun warp.
local fvs1_fin_vapeur_sommet = {}
return fvs1_fin_vapeur_sommet
