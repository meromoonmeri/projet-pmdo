-- ejs3_entree_jardin_secret_temple : base d edition, aucun warp.
local ejs3_entree_jardin_secret_temple = {}
return ejs3_entree_jardin_secret_temple
