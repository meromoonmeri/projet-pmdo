-- fgg1_fin_givre_grotte : base d edition (fin de donjon), aucun warp.
local fgg1_fin_givre_grotte = {}
return fgg1_fin_givre_grotte
