-- clr1_colonnes_lances : base d edition (fin de donjon), aucun warp.
local clr1_colonnes_lances = {}
return clr1_colonnes_lances
