-- ftc1_fin_clairiere_tropicale : base d edition, aucun warp.
local ftc1_fin_clairiere_tropicale = {}
return ftc1_fin_clairiere_tropicale
