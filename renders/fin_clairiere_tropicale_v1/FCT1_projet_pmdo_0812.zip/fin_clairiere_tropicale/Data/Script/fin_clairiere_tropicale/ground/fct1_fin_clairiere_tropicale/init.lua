-- fct1_fin_clairiere_tropicale; aucun warp.
local fct1_fin_clairiere_tropicale = {}
return fct1_fin_clairiere_tropicale
