-- fct1_fin_clairiere_tropicale : base d edition, aucun warp.
local fct1_fin_clairiere_tropicale = {}
return fct1_fin_clairiere_tropicale
