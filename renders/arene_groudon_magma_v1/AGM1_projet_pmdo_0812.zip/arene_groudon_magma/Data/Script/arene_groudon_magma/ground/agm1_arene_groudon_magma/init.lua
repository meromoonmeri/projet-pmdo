-- agm1_arene_groudon_magma : base d edition, aucun warp.
local agm1_arene_groudon_magma = {}
return agm1_arene_groudon_magma
