-- pvc1_passage_veines_cristallines: Ground d'édition; aucun warp automatique.
return {}
