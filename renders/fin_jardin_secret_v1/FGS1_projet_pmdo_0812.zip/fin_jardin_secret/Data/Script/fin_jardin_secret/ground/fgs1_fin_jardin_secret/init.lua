-- fgs1_fin_jardin_secret; aucun warp.
local fgs1_fin_jardin_secret = {}
return fgs1_fin_jardin_secret
