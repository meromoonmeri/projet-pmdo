-- fja1_fin_jardin_secret : base d edition, aucun warp.
local fja1_fin_jardin_secret = {}
return fja1_fin_jardin_secret
