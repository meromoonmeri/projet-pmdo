-- fiz1_fin_ile_zenith : base d edition, aucun warp.
local fiz1_fin_ile_zenith = {}
return fiz1_fin_ile_zenith
