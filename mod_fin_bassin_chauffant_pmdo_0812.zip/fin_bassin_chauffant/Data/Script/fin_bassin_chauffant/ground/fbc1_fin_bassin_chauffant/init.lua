-- fbc1_fin_bassin_chauffant : base d edition, aucun warp.
local fbc1_fin_bassin_chauffant = {}
return fbc1_fin_bassin_chauffant
