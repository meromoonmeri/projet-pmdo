-- ifz1_ile_flottante_zenith : base d edition, aucun warp.
local ifz1_ile_flottante_zenith = {}
return ifz1_ile_flottante_zenith
