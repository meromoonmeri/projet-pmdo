-- fpr1_fin_passage_ruines : base d edition, aucun warp.
local fpr1_fin_passage_ruines = {}
return fpr1_fin_passage_ruines
