-- eiz1_entree_ile_zenith : base d edition, aucun warp.
local eiz1_entree_ile_zenith = {}
return eiz1_entree_ile_zenith
