-- epr1_entree_passage_ruines : base d edition, aucun warp.
local epr1_entree_passage_ruines = {}
return epr1_entree_passage_ruines
