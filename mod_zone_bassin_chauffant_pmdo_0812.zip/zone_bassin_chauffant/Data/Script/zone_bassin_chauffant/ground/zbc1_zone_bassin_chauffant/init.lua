-- zbc1_zone_bassin_chauffant : base d edition, aucun warp.
local zbc1_zone_bassin_chauffant = {}
return zbc1_zone_bassin_chauffant
