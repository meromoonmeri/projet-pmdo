-- eac1_entree_chateau_ancien : base d edition, aucun warp.
local eac1_entree_chateau_ancien = {}
return eac1_entree_chateau_ancien
