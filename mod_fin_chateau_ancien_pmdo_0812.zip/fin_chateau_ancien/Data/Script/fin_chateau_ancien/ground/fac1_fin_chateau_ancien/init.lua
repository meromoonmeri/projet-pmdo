-- fac1_fin_chateau_ancien : base d edition, aucun warp.
local fac1_fin_chateau_ancien = {}
return fac1_fin_chateau_ancien
